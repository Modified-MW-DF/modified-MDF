package cz.zweistein.df.soundsense.gui;

import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class SoundsEditor extends JPanel {
	private static final long serialVersionUID = -1589111332608860451L;

	private SoundsEditor(String filename) {
		
	}
	
	public static SoundsEditor createAndShow(String filename) {
		// Create and set up the window.
		final JFrame frame = new JFrame("SoundSense Editor");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(Icons.APP_ICON));
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		frame.addWindowListener(new WindowListener() {

			@Override
			public void windowClosed(WindowEvent arg0) {
			}

			@Override
			public void windowActivated(WindowEvent arg0) {
			}

			@Override
			public void windowClosing(WindowEvent arg0) {
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {
			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {
			}

			@Override
			public void windowIconified(WindowEvent arg0) {
			}

			@Override
			public void windowOpened(WindowEvent arg0) {
			}

		});

		final SoundsEditor editor = new SoundsEditor(filename);

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {

				// Add content to the window.
				frame.add(editor, BorderLayout.CENTER);

				// Display the window.
				frame.pack();
				frame.setVisible(true);

			}
		});

		return editor;
	}

}
